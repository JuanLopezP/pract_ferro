======================
Railway Operation Simulator (RailOS)

@version : v2.16.1 64 bit
@date: August 2023
======================

There are two versions of the simulator - RailOS32.exe for the 32 bit Windows operating system (OS) and RailOS64.exe for the 64 bit Windows OS.  The 32 bit version will run on both 32 and 64 bit OSs, but if you have the 64 bit OS you are recommended to run RailOS64.exe.  If you have the 32 bit OS then you can only run RailOS32.exe.  To find out which version of Windows OS you have look at this article: https://support.microsoft.com/en-us/windows/32-bit-and-64-bit-windows-frequently-asked-questions-c6ca9541-8dce-4d48-0415-94a3faa2e13d

Downloading and installing RailOS64 v2.16.1.zip makes no changes to the registry nor to any other operating system or user settings. It does not require a complex installation procedure and does not have an uninstall program. If it isn’t wanted then just delete it, nothing else will be affected. It was developed under Windows 10 using Embarcadero’s C++ Builder compiler version 10.4. Krizar has created two very helpful videos showing in detail how to download, install and operate the program. These are available under the ‘Help’ tab on the website (www.railwayoperationsimulator.com).

***Important Notes***

1.  If you download both 32 and 64 bit versions please be sure to put them in their own folders e.g. Railway32' and 'Railway64'.  This is because each version has its own support files of the form .dll and .bpl, and some of these have the same names, though they are different files.

2.  Please don’t hide the Windows taskbar when running the program as it causes the screen to flash. Why this should happen isn’t known at present.

3.  If you intend to run RailOS on a high resolution monitor please see https://www.railwayoperationsimulator.com/help/10_high_resolution_monitors which explains how to avoid compatibility issues.  However it is hoped that RailOS64.exe won't be subject to these issues as they predominantly relate to 32 bit programs.

4.  Please be sure to add the included .dll and .bpl files to the folder where the program resides.

******

Unzipping file ‘RailOS64 v2.16.1.zip’ produces a folder named ‘Railway’, together with a user manual named ‘Manual v2.15.1.pdf’ (still valid for this version), a quick start guide named ‘Quick start.pdf’, ‘Readme 64bit.txt’, 'v2.16.1 release notes.txt' and a folder named ‘Metadata’ in the Railway folder, explained below.

The ‘Railway’ folder should be moved to the location from where the program is to run, and must be a read/write location – i.e. somewhere on a hard disk or a memory stick, but not a CDRom. For convenience, when the folder has been located, open up the folder and add a shortcut on the desktop to the main program file which is named ‘RailOS64.exe’. This can be done by right clicking on the .exe file icon in Windows Explorer, selecting ‘Send To’, then in the submenu selecting ‘Desktop (create shortcut)’.

Existing users should allow files in their existing ‘Railway’ folder to be replaced by new ones from the new folder.

We recommended printing ‘Quick Start.pdf’ (4 pages of A4) for reference during the first use of the program. ‘Manual v2.15.1.pdf’ is the program’s help file in a single document which can also be printed if you wish – it’s a 56 page A4 document – though the same information is available anytime from within the program via the ‘Help’ menu.

If you don’t have a ‘pdf’ reader please go to http://get.adobe.com/uk/reader/ to download a free copy.

A lot more help is available from the website (www.railwayoperationsimulator.com) under the ‘Help’ and then 'Tutorials' tabs. Krizar's videos have already been mentioned but there are also two quickstart videos available and a more in-depth series of four videos produced by Keith Hazelton entitled ‘Designing a Railway (with video)’. They provide a detailed introduction to the program and are highly recommended. Oxalin has also created a series of detailed tutorial videos showing how to use external resources to aid in designing and building railways, and in creating timetables. Timetabling is the most difficult aspect to learn, so help is available in the form of an introduction and online tutorials, and these tutorials are also downloadable under the ‘Downloads & Projects’ then ‘Base Program’ tabs. Also downloadable is a detailed explanation of timetable error messages.

There is a very active Discord community where projects are discussed along with many other things associated with railways, and if additional help is needed it can easily be obtained by posting your problem in the ‘helpdesk’ channel. You are invited to sign up by clicking the ‘Discord’ tab on the website.

The Metadata folder in the Railway folder contains two files, one for each of the two railways that come with the download – Birmingham and Liverpool. The files are of type .toml – ‘Tom’s Obvious Minimal Language’, which provides a format that is both human and computer-readable. Going forward it is intended to make more use of computer file reading, so users are encouraged to provide these files with any new railways that they submit to the website. More information about toml files can be found at https://toml.io/en/, and a list of country codes is provided at https://www.iso.org/obp/ui/#search/code.

That’s it – ready to go – we hope you like the program and find it useful.

Please let us know via Discord or the website how you get on with it – good points, bad points and any errors (hopefully few).

Best regards,

The RailOS team